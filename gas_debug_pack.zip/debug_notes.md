# Google Apps Script Web App "Unable to Open this File" Debug Notes

This package contains the source code of our Google Apps Script database gateway (which acts as a Diagnostics Dashboard and SQL-like API router) and the diagnostic details regarding the access issues encountered by the client.

---

## 📦 Package Contents
1. `Code.gs` - Main Web App gateway routing logic (doGet/doPost).
2. `setup.gs` - Setup script to initialize Google Sheet tables and authorize required API scopes.
3. `Index.html` - Premium UI Diagnostics Dashboard.
4. `appsscript.json` - Apps Script manifest declaring permissions and timezone settings.

---

## 🚨 Symptom Description
* **Target Web App URL**: `https://script.google.com/macros/s/AKfycbwoXAjRW4z01O5BR_6bAqf_Wx7Ev3P8Z-Pu3CV7Cj0iwnRo_vvd5Kn-FZbL-7zsXg2Urw/exec`
* **Target Spreadsheet ID**: `1_Pfzg81jyXP--08G-65auMSc_61tHt6182BGxfxVy0Q`
* **Configuration**: 
  * Execute as: **Me** (the script owner: `force.ai0001@gmail.com`)
  * Who has access: **Anyone** (所有人/任何人)
* **What Works**:
  * Anonymous, non-logged-in backend HTTP clients (e.g., node-fetch, Python requests, agent probes) can successfully fetch the raw HTML of the dashboard without any login redirection or block.
* **What Fails**:
  * When the user visits the URL via their mobile phone (both normal and private tabs) or certain desktop browser sessions, Google blocks the page and displays the Drive error message: **"Sorry, unable to open this file at this time. Please check the address and try again." (很抱歉，目前無法開啟這個檔案。請檢查網址並再試一次。)**.

---

## 🔍 Technical Hypotheses to Investigate

### 1. Browser ITP & Third-Party Cookie Policy (Most Likely)
* **Context**: Apps Script Web Apps run user HTML inside a sandboxed iframe hosted on `script.googleusercontent.com`, while the top-level window is `script.google.com`.
* **Behavior**: To synchronize states and allow the iframe to load under the owner's execution context, Google relies on third-party cookies or session matching between `script.google.com` and `script.googleusercontent.com`.
* **Issue**: iOS Safari, Chrome on iOS, and built-in webviews (like LINE or WeChat in-app browsers) block third-party cookies by default via **Intelligent Tracking Prevention (ITP)**. If these cookies are blocked, the iframe fails to load and Google throws the Drive error page.
* **Question**: How can we design the Web App to load reliably on mobile devices and private windows without requiring users to manually disable "Prevent Cross-Site Tracking"?

### 2. Multi-Account Google Session Conflict
* **Context**: Many users have multiple Google accounts (e.g., personal Gmail and Google Workspace company accounts) logged in on the same browser.
* **Behavior**: Google automatically appends session indices like `/u/0/` or `/u/1/` to the URL.
* **Issue**: If the active session is a corporate Google Workspace account, its organizational policy might block running external scripts, causing the Web App to crash even if the link is correct.
* **Question**: Is there a way to enforce session isolation or force the script to execute using the correct account session?

### 3. File & Scope Authorization Issues
* **Context**: The script uses `SpreadsheetApp`, `DriveApp`, and `UrlFetchApp`.
* **Behavior**: The owner has executed `authorizeAllScopes` in the GAS editor to approve all three scopes.
* **Question**: Is there any hidden permission check where Google links the standalone script's execution to the private sheet's share settings, even when deployed as "Execute as: Me"?

---

## 🛠️ Task for Peer AIs
Please analyze the attached files (`Code.gs`, `setup.gs`, `Index.html`, `appsscript.json`) and the hypotheses above. 
Provide a clear architectural solution to make this Apps Script Web App reliably accessible to anonymous users (for both API and HTML visual display) while keeping the target Google Sheet private.
